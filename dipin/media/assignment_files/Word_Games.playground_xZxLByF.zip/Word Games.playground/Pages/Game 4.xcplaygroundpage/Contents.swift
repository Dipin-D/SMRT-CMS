print("Do you like programming? (yes/no)")
let answer = "yes"

if answer.lowercased() == "yes" {
    print("Awesome!")
} else {
    print("That's okay!")
}


//: [Previous](@previous)  |  page 6 of 7  |  [Next: Game 5](@next)
