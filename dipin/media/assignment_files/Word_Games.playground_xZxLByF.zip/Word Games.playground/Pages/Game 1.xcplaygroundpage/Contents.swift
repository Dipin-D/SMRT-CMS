print("Enter a number:")
let number = 9

if number % 2 == 0 {
    print("\(number) is even.")
} else {
    print("\(number) is odd.")
}

