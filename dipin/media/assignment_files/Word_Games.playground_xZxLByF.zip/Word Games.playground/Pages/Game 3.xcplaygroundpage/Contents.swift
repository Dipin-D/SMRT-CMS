let correctAge = 21
print("Guess my age:")
let ageGuess = 22

if ageGuess == correctAge {
    print("You guessed it right!")
} else {
    print("Nope! I'm \(correctAge).")
}


//: [Previous](@previous)  |  page 5 of 7  |  [Next: Game 4](@next)
