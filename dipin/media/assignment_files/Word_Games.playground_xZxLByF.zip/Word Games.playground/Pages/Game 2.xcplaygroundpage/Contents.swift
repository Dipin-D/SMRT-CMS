print("Enter a word:")
let word = "alright"
let reversedWord = String(word.reversed())

print("Your word reversed is: \(reversedWord)")



//: [Previous](@previous)  |  page 4 of 7  |  [Next: Game 3](@next)
